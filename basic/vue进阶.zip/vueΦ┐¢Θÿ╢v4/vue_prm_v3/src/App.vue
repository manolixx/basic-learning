<template>
  <img alt="Vue logo" src="./assets/logo.png">
  <HelloWorld>
    <!-- 默认插槽 -->
    <p>{{ msg }}</p>
    <p>{{ msg1 }}</p>
    <p>{{ msg2 }}</p>
    <!-- 具名插槽 - name -->
    <template v-slot:header>{{ header }}</template>
    <template v-slot:footer>{{ footer }}</template>
    <!-- 作用域插槽 -->
    <template #content="slotProps">{{ slotProps }}</template>
  </HelloWorld>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
    HelloWorld
  },
  data() {
    return {
      msg: 'zhaowa',
      msg1: 'zhaowa1',
      msg2: 'zhaowa2',
      header: 'zhaowa header',
      footer: 'zhaowa footer'
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
