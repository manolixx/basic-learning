<script>
import { render } from 'vue';

export default {
    name: 'HelloWorld1',
    data() {
        return {
            options: [{
                value: 1
            }, {
                value: 2
            }]
        }
    },
    methods: {
        handleClick() {}
    },
    render(h) {
        // createElement
        // h('div', ...props)
        // template => render() => 产出
        // 嵌套
        const moneyNode = (
            <p>{ this.money > 99 ? 99 : this.money }</p>
        )
        return (
            <ul>
                {
                    this.options.map(item => {
                        return (
                            <content
                                item={item}
                                onClick={this.handleClick}
                            >
                                { this.options }
                                { moneyNode }
                            </content>
                        )
                    })
                }
            </ul>
        )
    }
}
</script>