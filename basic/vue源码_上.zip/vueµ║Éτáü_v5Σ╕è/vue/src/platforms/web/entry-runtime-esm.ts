import Vue from './runtime/index'

export default Vue

export * from 'v3'
